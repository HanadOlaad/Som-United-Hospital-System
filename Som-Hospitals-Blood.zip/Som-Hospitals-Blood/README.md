# Blood_Bank_Management_System
[![GitHub license](https://img.shields.io/github/license/VirusZzHkP/Blood_Bank_Management_System?style=for-the-badge)](https://github.com/VirusZzHkP/Blood_Bank_Management_System/blob/main/LICENSE)
![GitHub top language](https://img.shields.io/github/languages/top/VirusZzHkP/Blood_Bank_Management_System?color=gree&style=for-the-badge)



This project will help user &amp; hospital to know the availability of bloods, users as well as hospitals can request blood samples , users can search for blood group he/she wants.
