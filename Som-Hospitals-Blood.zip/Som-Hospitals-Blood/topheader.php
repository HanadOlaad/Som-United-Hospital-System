<div class="brand clearfix">
	<!-- <a href="dashboard.php" style="font-size: 25px;"><img src="assets/images/Phlogo.png" alt="image"/></a>   -->
	<div class="logo"> <a href="hospitalpage.php"><img src="img/Hlogo.png" alt="image"/></a> </div>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			
		<li class="ts-account">
    <a href="#"><img src="img/avatar.png" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
    <ul>
        <li><a href="change-password.php">Change Password</a></li>
        <li><a href="logout.php">Logout</a></li>
        <li><a href="uploadprofile.php">Upload Profile</a></li> <!-- Add this line -->
    </ul>
</li>
		</ul>
	</div>
